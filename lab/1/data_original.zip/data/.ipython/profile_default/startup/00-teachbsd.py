# Common imports used by TeachBSD
import time
import json
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import copy
from dtrace import DTraceConsumer, DTraceConsumerThread

# List of Python objects - updated each time the simple_out callback
# is invoked
values = None 

# DTraceConsumerThread object
consumer_thread = None

# Callback invoked when a DTrace probe fires
def no_output_chew(_cpu):
	pass

# Callback invoked for each DTrace record being processed
def no_output_chewrec(_action):
	pass

# Callback invoked for each output
def simple_out(raw_value):
	global values
	values.append(raw_value)

# Create a DTraceConsumerThread to process the script.
# The DTrace script is ran in a seperate thread allowing it to run
# the benchmark and collect input.
def start_instr_benchmark(script):
	global values
	global consumer_thread 
	values = []
        consumer_thread = DTraceConsumerThread(script,
		chew_func=no_output_chew,
		chewrec_func=no_output_chewrec,
		out_func=simple_out,
		walk_func=None,
		sleep=1)
	consumer_thread.start()

# Stop the DTraceConsumerThread and wait for it to finish.	
def stop_instr_benchmark():
	global consumer_thread 
	consumer_thread.stop()
	consumer_thread.join()

# Return a (deep) copy of the values list
def get_instr_values():
	global values
	return copy.deepcopy(values)

# Display a simple header
def print_header(header_text):
	sys.stdout.write(80*"*")
        if type(header_text) is list:
		for line in header_text:
			sys.stdout.write("\n* " + line)
	else:
		sys.stdout.write("\n* " + header_text)
	sys.stdout.write("\n" + 80*"*" + "\n")

# Display a simple footer 
def print_footer(footer_text):
	sys.stdout.write(80*"*")
        if type(footer_text) is list:
		for line in footer_text:
			sys.stdout.write("\n* " + line)
	else:
		sys.stdout.write("\n* " + footer_text)
	sys.stdout.write("\n" + 80*"*" + "\n")
